# Clean-up Report - Demo Burger Group

| | |
|---|---|
| Customer ID | TEST-0003 |
| Report ID | TEST-0003-analysis-20261107173941-db1 |
| Business type | Restaurant |
| Analysis time frame | Jan 01, 2023 - Dec 31, 2025 |
| Data period (order_datetime) | Jan 01, 2023 - Dec 31, 2025 |
| Source file | taqueria_3_years_messy.csv |
| Created | 2026-11-07 18:47 |

**Status:** 46 rows still need a fix. They are left out of the numbers below and saved in the bad rows file so they can be fixed and sent again.

## Data quality
- Rows uploaded: 300,060
- Clean rows: 299,913
- Bad rows found: 26,296
- Fixed by you and added back: 26,149
- Deleted by you (duplicates or unusable): 101
- Still to fix: 46

## Problems found at upload

| Problem | Rows |
|---|---|
| missing information | 6,563 |
| garbled characters | 5,433 |
| text in a number column | 3 |
| not a valid date | 3 |
| negative number | 15 |
| spelling differs | 14,744 |
| unusual value | 61 |
| duplicate row | 97 |

## Column by column

Only columns that need attention. *Missing data, not bad* and *partly reported, not bad* columns don't make any row bad.

| Column | Status | Blank | Wrong cells |
|---|---|---|---|
| order_datetime | needs checking | 0 | 3 |
| item | needs checking | 0 | 1,616 |
| category | needs checking | 0 | 8,940 |
| quantity | needs checking | 0 | 8 |
| unit_price | needs checking | 0 | 4 |
| order_total | needs checking | 0 | 9 |
| discount_amount | needs checking | 0 | 57 |
| channel | needs checking | 1,800 | 5,886 |
| employee | needs checking | 3,602 | 7,554 |
| payment_method | needs checking | 1,200 | 2,992 |

## What we did in this job
1. Received **taqueria_3_years_messy.csv** with 300,060 rows and saved an untouched copy with its fingerprint.
2. Identified the columns. All column names were kept as they are.
3. Checked every column first, then every cell: blanks, text in number columns, dates, negative and unusual numbers, spellings, garbled accents and duplicates.
4. Found 26,296 bad rows. You fixed 26,149, deleted 101 and 46 are still to fix.
5. Every fixed row is marked **fixed** with the date, and every row has its own fingerprint.
6. **Clerk time saved:** not shown yet. It is calculated from the clerk hours and hourly rate entered at sign-up.

## Rows still pending

- **46 rows still need cleaning.** They are not in the numbers of this report. They are saved, and they will come back automatically with your next upload, marked as pending from this report. Please fix them before the next monthly clean-up.

## Analysis
**Plan: Basic + Analysis.** $1,600.00 per database ($1,200.00 Basic + $400.00 Analysis). Includes the clean-up, the data repair and the data analysis below.

**Time frame:** Jan 01, 2023 - Dec 31, 2025 · 299,913 rows

How to read this report: every section shows **each year on its own**, with its months, so you can see what went up and what went down. Every total says which time frame it covers. **Sales** always means sales after discounts. A change with **+** went up (+4.2% = 4.2% more); with **-** it went down.

## Key numbers

The main numbers for each year. The **Total** column covers the whole time frame: Jan 01, 2023 - Dec 31, 2025 (3 years: 2023, 2024, 2025).

| Measure | 2023 | 2024 | 2025 | Total |
|---|---|---|---|---|
| Sales | $1,402,135.10 | $1,411,368.80 | $1,404,116.20 | $4,217,620.10 |
| Discounts | $8,375.40 | $8,323.20 | $8,150.80 | $24,849.40 |
| Orders | 44,864 | 45,342 | 44,688 | 134,893 |
| Average sale per order | $31.25 | $31.13 | $31.42 | $31.27 |
| Items sold | 199,410 | 201,185 | 199,292 | 599,887 |
| Average sales per day | $3,841.47 | $3,856.20 | $3,846.89 | $3,848.19 |
| Guests | 154,715 | 155,967 | 153,837 | 464,518 |
| Sales per guest | $9.06 | $9.05 | $9.13 | $9.08 |

### Up or down compared with the year before

Each year compared with the year before it. Averages per day and per order are fair even when a year has fewer months of data.

| Measure | 2024 vs 2023 | 2025 vs 2024 |
|---|---|---|
| Sales | +0.7% | -0.5% |
| Discounts | -0.6% | -2.1% |
| Orders | +1.1% | -1.4% |
| Average sale per order | -0.4% | +0.9% |
| Items sold | +0.9% | -0.9% |
| Average sales per day | +0.4% | -0.2% |
| Guests | +0.8% | -1.4% |
| Sales per guest | -0.1% | +0.9% |

## Monthly sales by year

Each year is listed on its own, month by month. What each column means:

- **Average per day**: the month's sales divided by its days. It makes short and long months fair to compare.
- **vs month before**: how the average per day changed from the month before. February is compared fairly with January even though it has fewer days.
- **Since last December**: where the year stands so far. Every month is compared with the December before the year started, so the number does not add up mistakes month after month. **December shows the real change for the whole year.** The first year in the file has no December before it, so it starts from its own January.
- **vs same month last year**: this month compared with the same month one year before. It removes the seasons: if February is always slow, this column shows whether this February was better or worse.

*Chart in the PDF report: Sales by month, one line per year*

### 2023

*Since last December* is measured from **Jan 2023**.

| Month | Orders | Items sold | Sales | Average per day | vs month before | Since last December | vs same month last year |
|---|---|---|---|---|---|---|---|
| Jan | 3,918 | 17,269 | $121,276 | $3,912 | - | start | - |
| Feb | 3,481 | 15,388 | $108,140 | $3,862 | -1.3% | -1.3% | - |
| Mar | 3,916 | 17,024 | $120,239 | $3,879 | +0.4% | -0.9% | - |
| Apr | 3,693 | 16,256 | $114,622 | $3,821 | -1.5% | -2.3% | - |
| May | 3,739 | 16,820 | $118,999 | $3,839 | +0.5% | -1.9% | - |
| Jun | 3,740 | 16,224 | $114,417 | $3,814 | -0.6% | -2.5% | - |
| Jul | 3,774 | 16,732 | $116,814 | $3,768 | -1.2% | -3.7% | - |
| Aug | 3,744 | 17,016 | $119,416 | $3,852 | +2.2% | -1.5% | - |
| Sep | 3,594 | 16,373 | $115,395 | $3,846 | -0.1% | -1.7% | - |
| Oct | 3,794 | 16,926 | $118,530 | $3,824 | -0.6% | -2.3% | - |
| Nov | 3,625 | 16,543 | $115,542 | $3,851 | +0.7% | -1.6% | - |
| Dec | 3,846 | 16,839 | $118,745 | $3,830 | -0.5% | -2.1% | - |
| **Total 2023** | **44,864** | **199,410** | **$1,402,135** | **$3,841** |  |  |  |

### 2024

*Since last December* is measured from **Dec 2023**.

| Month | Orders | Items sold | Sales | Average per day | vs month before | Since last December | vs same month last year |
|---|---|---|---|---|---|---|---|
| Jan | 3,849 | 16,728 | $118,496 | $3,822 | -0.2% | -0.2% | -2.3% |
| Feb | 3,593 | 16,078 | $110,760 | $3,819 | -0.1% | -0.3% | -1.1% |
| Mar | 3,934 | 17,115 | $119,321 | $3,849 | +0.8% | +0.5% | -0.8% |
| Apr | 3,660 | 16,431 | $116,865 | $3,896 | +1.2% | +1.7% | +2.0% |
| May | 3,810 | 16,884 | $118,798 | $3,832 | -1.6% | 0.0% | -0.2% |
| Jun | 3,738 | 16,675 | $115,424 | $3,847 | +0.4% | +0.4% | +0.9% |
| Jul | 3,854 | 17,054 | $120,242 | $3,879 | +0.8% | +1.3% | +2.9% |
| Aug | 3,866 | 16,991 | $119,692 | $3,861 | -0.5% | +0.8% | +0.2% |
| Sep | 3,706 | 16,768 | $116,893 | $3,896 | +0.9% | +1.7% | +1.3% |
| Oct | 3,883 | 17,206 | $120,095 | $3,874 | -0.6% | +1.1% | +1.3% |
| Nov | 3,674 | 16,231 | $115,273 | $3,842 | -0.8% | +0.3% | -0.2% |
| Dec | 3,775 | 17,024 | $119,511 | $3,855 | +0.3% | +0.6% | +0.6% |
| **Total 2024** | **45,342** | **201,185** | **$1,411,369** | **$3,856** |  |  | **+0.4%** |

### 2025

*Since last December* is measured from **Dec 2024**.

| Month | Orders | Items sold | Sales | Average per day | vs month before | Since last December | vs same month last year |
|---|---|---|---|---|---|---|---|
| Jan | 3,731 | 16,577 | $117,100 | $3,777 | -2.0% | -2.0% | -1.2% |
| Feb | 3,447 | 15,353 | $106,499 | $3,804 | +0.7% | -1.3% | -0.4% |
| Mar | 3,859 | 17,081 | $120,581 | $3,890 | +2.3% | +0.9% | +1.1% |
| Apr | 3,623 | 16,381 | $114,607 | $3,820 | -1.8% | -0.9% | -1.9% |
| May | 3,723 | 16,837 | $119,429 | $3,853 | +0.8% | -0.1% | +0.5% |
| Jun | 3,615 | 16,161 | $113,581 | $3,786 | -1.7% | -1.8% | -1.6% |
| Jul | 3,881 | 16,973 | $119,988 | $3,871 | +2.2% | +0.4% | -0.2% |
| Aug | 3,891 | 17,061 | $120,515 | $3,888 | +0.4% | +0.8% | +0.7% |
| Sep | 3,563 | 16,424 | $116,653 | $3,888 | 0.0% | +0.9% | -0.2% |
| Oct | 3,818 | 16,887 | $118,879 | $3,835 | -1.4% | -0.5% | -1.0% |
| Nov | 3,606 | 16,266 | $114,931 | $3,831 | -0.1% | -0.6% | -0.3% |
| Dec | 3,931 | 17,291 | $121,353 | $3,915 | +2.2% | +1.5% | +1.5% |
| **Total 2025** | **44,688** | **199,292** | **$1,404,116** | **$3,847** |  |  | **-0.2%** |

## Best-selling item of each month

The item that brought in the most money each month. Within each year the months go from the highest sales to the lowest. **Times sold** = how many sale lines had it.

### 2023

| Month | ID | Item | Items sold | Times sold | Sales |
|---|---|---|---|---|---|
| Apr | TQ-109 | Pozole | 971 | 463 | $12,578.00 |
| Aug | TQ-109 | Pozole | 970 | 480 | $12,574.00 |
| Oct | TQ-109 | Pozole | 963 | 476 | $12,475.00 |
| Dec | TQ-109 | Pozole | 962 | 480 | $12,467.00 |
| Jan | TQ-109 | Pozole | 945 | 491 | $12,244.00 |
| Jun | TQ-109 | Pozole | 932 | 464 | $12,080.00 |
| May | TQ-106 | Enchiladas Rojas | 1,004 | 483 | $12,010.00 |
| Jul | TQ-109 | Pozole | 925 | 473 | $11,985.00 |
| Mar | TQ-109 | Pozole | 911 | 462 | $11,811.00 |
| Nov | TQ-109 | Pozole | 900 | 453 | $11,669.00 |
| Sep | TQ-109 | Pozole | 891 | 458 | $11,545.00 |
| Feb | TQ-109 | Pozole | 840 | 412 | $10,852.40 |

### 2024

| Month | ID | Item | Items sold | Times sold | Sales |
|---|---|---|---|---|---|
| Dec | TQ-109 | Pozole | 1,012 | 513 | $13,116.00 |
| Aug | TQ-109 | Pozole | 991 | 469 | $12,847.00 |
| Nov | TQ-109 | Pozole | 963 | 481 | $12,488.00 |
| Jul | TQ-109 | Pozole | 962 | 504 | $12,457.60 |
| Oct | TQ-109 | Pozole | 943 | 468 | $12,222.00 |
| Jan | TQ-109 | Pozole | 940 | 470 | $12,179.00 |
| May | TQ-109 | Pozole | 910 | 461 | $11,794.00 |
| Mar | TQ-109 | Pozole | 894 | 456 | $11,590.00 |
| Apr | TQ-106 | Enchiladas Rojas | 949 | 473 | $11,346.00 |
| Jun | TQ-109 | Pozole | 858 | 425 | $11,122.00 |
| Sep | TQ-106 | Enchiladas Rojas | 907 | 458 | $10,852.00 |
| Feb | TQ-109 | Pozole | 800 | 408 | $10,364.00 |

### 2025

| Month | ID | Item | Items sold | Times sold | Sales |
|---|---|---|---|---|---|
| Mar | TQ-109 | Pozole | 994 | 492 | $12,891.00 |
| Jul | TQ-109 | Pozole | 993 | 484 | $12,877.00 |
| Aug | TQ-109 | Pozole | 977 | 496 | $12,648.00 |
| Jan | TQ-109 | Pozole | 970 | 465 | $12,569.00 |
| Oct | TQ-109 | Pozole | 968 | 485 | $12,539.00 |
| Dec | TQ-106 | Enchiladas Rojas | 1,034 | 511 | $12,362.00 |
| Sep | TQ-109 | Pozole | 932 | 461 | $12,079.00 |
| Nov | TQ-109 | Pozole | 925 | 445 | $11,981.00 |
| May | TQ-109 | Pozole | 912 | 440 | $11,824.00 |
| Jun | TQ-109 | Pozole | 911 | 438 | $11,806.00 |
| Apr | TQ-109 | Pozole | 906 | 458 | $11,741.00 |
| Feb | TQ-109 | Pozole | 811 | 425 | $10,508.00 |

## Top 10 items of each year

The 10 items that brought in the most money each year. **Percent of total sales** = how much of all the year's sales came from it: 10% means 10 of every 100 dollars sold. **Rank last year** shows where it was the year before, to see what is rising or falling.

### 2023

In 2023, **12 of 18 items** brought in 80% of the sales: they deserve the most attention in stock, price and quality.

| # | ID | Item | Category | Items sold | Sales | Percent of total sales |
|---|---|---|---|---|---|---|
| 1 | TQ-109 | Pozole | Food | 11,120 | $144,054 | 10.3% |
| 2 | TQ-106 | Enchiladas Rojas | Food | 11,170 | $133,500 | 9.5% |
| 3 | TQ-103 | Burrito Supremo | Food | 11,200 | $128,273 | 9.1% |
| 4 | TQ-114 | Margarita | Bar | 11,056 | $110,092 | 7.9% |
| 5 | TQ-107 | Nachos Grandes | Food | 11,074 | $107,554 | 7.7% |
| 6 | TQ-113 | Piña Colada | Bar | 11,230 | $100,627 | 7.2% |
| 7 | TQ-104 | Quesadilla | Food | 10,850 | $89,024 | 6.3% |
| 8 | TQ-108 | Tamales de Puerco | Food | 11,172 | $83,327 | 5.9% |
| 9 | TQ-105 | Jalapeño Poppers | Food | 10,975 | $70,881 | 5.1% |
| 10 | TQ-118 | Pastel de Tres Leches | Dessert | 10,901 | $67,724 | 4.8% |

#### Slowest items in 2023 (fewest sold)

| ID | Item | Items sold | Sales |
|---|---|---|---|
| TQ-104 | Quesadilla | 10,850 | $89,024 |
| TQ-115 | Cerveza | 10,875 | $64,761 |
| TQ-118 | Pastel de Tres Leches | 10,901 | $67,724 |
| TQ-116 | Churros | 10,954 | $59,812 |
| TQ-105 | Jalapeño Poppers | 10,975 | $70,881 |

### 2024

In 2024, **12 of 18 items** brought in 80% of the sales: they deserve the most attention in stock, price and quality.

| # | ID | Item | Category | Items sold | Sales | Percent of total sales | Rank last year |
|---|---|---|---|---|---|---|---|
| 1 | TQ-109 | Pozole | Food | 10,947 | $141,866 | 10.1% | 1 |
| 2 | TQ-106 | Enchiladas Rojas | Food | 11,005 | $131,565 | 9.3% | 2 |
| 3 | TQ-103 | Burrito Supremo | Food | 11,167 | $127,968 | 9.1% | 3 |
| 4 | TQ-114 | Margarita | Bar | 11,132 | $110,857 | 7.9% | 4 |
| 5 | TQ-107 | Nachos Grandes | Food | 11,118 | $107,905 | 7.6% | 5 |
| 6 | TQ-113 | Piña Colada | Bar | 11,134 | $99,735 | 7.1% | 6 |
| 7 | TQ-104 | Quesadilla | Food | 11,449 | $94,002 | 6.7% | 7 |
| 8 | TQ-108 | Tamales de Puerco | Food | 11,424 | $85,202 | 6.0% | 8 |
| 9 | TQ-105 | Jalapeño Poppers | Food | 11,022 | $71,201 | 5.0% | 9 |
| 10 | TQ-118 | Pastel de Tres Leches | Dessert | 11,367 | $70,583 | 5.0% | 10 |

#### Slowest items in 2024 (fewest sold)

| ID | Item | Items sold | Sales |
|---|---|---|---|
| TQ-109 | Pozole | 10,947 | $141,866 |
| TQ-106 | Enchiladas Rojas | 11,005 | $131,565 |
| TQ-105 | Jalapeño Poppers | 11,022 | $71,201 |
| TQ-116 | Churros | 11,061 | $60,384 |
| TQ-107 | Nachos Grandes | 11,118 | $107,905 |

### 2025

In 2025, **12 of 18 items** brought in 80% of the sales: they deserve the most attention in stock, price and quality.

| # | ID | Item | Category | Items sold | Sales | Percent of total sales | Rank last year |
|---|---|---|---|---|---|---|---|
| 1 | TQ-109 | Pozole | Food | 11,182 | $144,899 | 10.3% | 1 |
| 2 | TQ-106 | Enchiladas Rojas | Food | 11,090 | $132,635 | 9.4% | 2 |
| 3 | TQ-103 | Burrito Supremo | Food | 11,350 | $130,049 | 9.3% | 3 |
| 4 | TQ-114 | Margarita | Bar | 11,012 | $109,668 | 7.8% | 4 |
| 5 | TQ-107 | Nachos Grandes | Food | 11,237 | $109,108 | 7.8% | 5 |
| 6 | TQ-113 | Piña Colada | Bar | 11,200 | $100,324 | 7.1% | 6 |
| 7 | TQ-104 | Quesadilla | Food | 11,003 | $90,285 | 6.4% | 7 |
| 8 | TQ-108 | Tamales de Puerco | Food | 10,932 | $81,520 | 5.8% | 8 |
| 9 | TQ-105 | Jalapeño Poppers | Food | 10,880 | $70,278 | 5.0% | 9 |
| 10 | TQ-118 | Pastel de Tres Leches | Dessert | 10,992 | $68,301 | 4.9% | 10 |

#### Slowest items in 2025 (fewest sold)

| ID | Item | Items sold | Sales |
|---|---|---|---|
| TQ-102 | Taco de Asada | 10,872 | $40,356 |
| TQ-105 | Jalapeño Poppers | 10,880 | $70,278 |
| TQ-108 | Tamales de Puerco | 10,932 | $81,520 |
| TQ-118 | Pastel de Tres Leches | 10,992 | $68,301 |
| TQ-116 | Churros | 10,994 | $60,000 |

*Chart in the PDF report: Top 10 items by sales in 2025*

## Sales by category

How much each category sold each year, and whether it went up or down. Spellings like *food*, *FOOD* and *Food* count as one. Below, each year month by month.

| Category | 2023 | 2024 | 2025 | 2025 vs 2024 | Percent of total sales 2025 |
|---|---|---|---|---|---|
| Food | $837,027 | $839,973 | $837,310 | -0.3% | 59.6% |
| Bar | $275,479 | $276,983 | $275,816 | -0.4% | 19.6% |
| Dessert | $183,074 | $186,384 | $184,965 | -0.8% | 13.2% |
| Drinks | $106,555 | $108,028 | $106,025 | -1.9% | 7.6% |

*Chart in the PDF report: Sales by category and year*

### 2023 month by month

| Month | Food | Bar | Dessert | Drinks | Total |
|---|---|---|---|---|---|
| Jan | $73,126 | $22,829 | $16,258 | $9,062 | $121,276 |
| Feb | $63,399 | $22,379 | $14,587 | $7,775 | $108,140 |
| Mar | $70,325 | $24,983 | $15,984 | $8,947 | $120,239 |
| Apr | $69,077 | $22,151 | $14,690 | $8,704 | $114,622 |
| May | $71,697 | $23,444 | $15,064 | $8,794 | $118,999 |
| Jun | $69,458 | $22,421 | $13,869 | $8,669 | $114,417 |
| Jul | $69,697 | $22,244 | $15,621 | $9,252 | $116,814 |
| Aug | $72,276 | $22,257 | $15,697 | $9,185 | $119,416 |
| Sep | $68,737 | $22,835 | $15,256 | $8,567 | $115,395 |
| Oct | $70,470 | $23,373 | $15,283 | $9,404 | $118,530 |
| Nov | $68,420 | $23,463 | $14,621 | $9,038 | $115,542 |
| Dec | $70,344 | $23,100 | $16,143 | $9,158 | $118,745 |
| **Total 2023** | **$837,027** | **$275,479** | **$183,074** | **$106,555** | **$1,402,135** |

### 2024 month by month

| Month | Food | Bar | Dessert | Drinks | Total |
|---|---|---|---|---|---|
| Jan | $70,326 | $23,595 | $15,784 | $8,790 | $118,496 |
| Feb | $65,178 | $21,667 | $15,045 | $8,870 | $110,760 |
| Mar | $71,017 | $23,746 | $15,188 | $9,370 | $119,321 |
| Apr | $70,896 | $22,715 | $14,804 | $8,450 | $116,865 |
| May | $71,313 | $22,815 | $15,792 | $8,878 | $118,798 |
| Jun | $67,644 | $22,067 | $16,458 | $9,255 | $115,424 |
| Jul | $71,952 | $23,970 | $15,366 | $8,954 | $120,242 |
| Aug | $71,460 | $23,431 | $15,988 | $8,813 | $119,692 |
| Sep | $67,900 | $24,543 | $15,157 | $9,292 | $116,893 |
| Oct | $72,486 | $21,892 | $16,603 | $9,114 | $120,095 |
| Nov | $68,382 | $22,844 | $15,453 | $8,594 | $115,273 |
| Dec | $71,418 | $23,698 | $14,747 | $9,648 | $119,511 |
| **Total 2024** | **$839,973** | **$276,983** | **$186,384** | **$108,028** | **$1,411,369** |

### 2025 month by month

| Month | Food | Bar | Dessert | Drinks | Total |
|---|---|---|---|---|---|
| Jan | $69,610 | $22,796 | $15,960 | $8,734 | $117,100 |
| Feb | $62,462 | $20,956 | $14,656 | $8,425 | $106,499 |
| Mar | $72,139 | $23,926 | $15,479 | $9,037 | $120,581 |
| Apr | $67,381 | $22,872 | $15,701 | $8,654 | $114,607 |
| May | $71,168 | $23,974 | $15,446 | $8,841 | $119,429 |
| Jun | $68,525 | $21,620 | $14,834 | $8,602 | $113,581 |
| Jul | $71,419 | $24,300 | $15,256 | $9,013 | $119,988 |
| Aug | $72,674 | $23,393 | $15,396 | $9,052 | $120,515 |
| Sep | $70,510 | $22,711 | $14,495 | $8,937 | $116,653 |
| Oct | $70,778 | $22,349 | $16,682 | $9,070 | $118,879 |
| Nov | $69,083 | $22,569 | $14,670 | $8,608 | $114,931 |
| Dec | $71,561 | $24,350 | $16,390 | $9,053 | $121,353 |
| **Total 2025** | **$837,310** | **$275,816** | **$184,965** | **$106,025** | **$1,404,116** |

## When customers buy

Average sales on each day of the week, and sales by hour, for each year. In 2025, **Tuesday** was the strongest day and **20:00 to 21:00** the busiest hour: use this to plan staff, preparation and promotions.

### Average sales per day of the week

| Day | Average per day 2023 | Average per day 2024 | Average per day 2025 | 2025 vs 2024 |
|---|---|---|---|---|
| Monday | $3,796 | $3,828 | $3,870 | +1.1% |
| Tuesday | $3,800 | $3,899 | $3,901 | +0.1% |
| Wednesday | $3,896 | $3,823 | $3,817 | -0.2% |
| Thursday | $3,865 | $3,831 | $3,777 | -1.4% |
| Friday | $3,794 | $3,839 | $3,877 | +1.0% |
| Saturday | $3,850 | $3,907 | $3,899 | -0.2% |
| Sunday | $3,887 | $3,866 | $3,789 | -2.0% |

*Chart in the PDF report: Average sales per day of the week, by year*

### Sales by hour of the day

**Percent of the day's sales** = how much of the year's sales happened in that hour.

| Hour | Sales 2023 | Sales 2024 | Sales 2025 | Percent of the day's sales 2025 |
|---|---|---|---|---|
| 11:00 | $126,440 | $129,991 | $125,641 | 8.9% |
| 12:00 | $128,606 | $126,972 | $127,716 | 9.1% |
| 13:00 | $129,484 | $126,458 | $129,514 | 9.2% |
| 14:00 | $128,212 | $129,539 | $126,414 | 9.0% |
| 15:00 | $126,815 | $129,448 | $128,237 | 9.1% |
| 16:00 | $128,254 | $126,744 | $125,915 | 9.0% |
| 17:00 | $126,694 | $129,382 | $128,209 | 9.1% |
| 18:00 | $127,159 | $131,138 | $129,794 | 9.2% |
| 19:00 | $125,790 | $125,286 | $128,386 | 9.1% |
| 20:00 | $129,020 | $129,287 | $130,034 | 9.3% |
| 21:00 | $125,660 | $127,125 | $124,258 | 8.8% |

*Chart in the PDF report: Sales by hour of the day, by year*

## How customers order and pay

Sales by channel (for example dine-in, takeout, delivery) and by payment method, each year and month by month. Look for channels that grow or shrink from one year to the next.

### Sales by channel and year

| Channel | 2023 | 2024 | 2025 | 2025 vs 2024 | Percent of total sales 2025 |
|---|---|---|---|---|---|
| Dine-in | $767,388 | $772,092 | $769,754 | -0.3% | 54.8% |
| Takeout | $418,093 | $420,290 | $417,797 | -0.6% | 29.8% |
| Delivery | $208,360 | $209,852 | $209,018 | -0.4% | 14.9% |
| Service Type | $8,294 | $9,134 | $7,547 | -17.4% | 0.5% |

*Chart in the PDF report: Sales by channel and year*

#### Channels in 2023, month by month

| Month | Dine-in | Takeout | Delivery | Service Type | Total |
|---|---|---|---|---|---|
| Jan | $66,836 | $35,182 | $18,594 | $664 | $121,276 |
| Feb | $59,317 | $31,992 | $16,372 | $458 | $108,140 |
| Mar | $65,925 | $36,306 | $17,145 | $862 | $120,239 |
| Apr | $62,523 | $34,532 | $16,688 | $880 | $114,622 |
| May | $65,488 | $35,270 | $17,755 | $486 | $118,999 |
| Jun | $62,416 | $34,161 | $17,163 | $677 | $114,417 |
| Jul | $64,445 | $35,025 | $16,736 | $609 | $116,814 |
| Aug | $65,552 | $35,757 | $17,562 | $544 | $119,416 |
| Sep | $63,898 | $33,558 | $17,210 | $729 | $115,395 |
| Oct | $63,179 | $36,676 | $17,770 | $905 | $118,530 |
| Nov | $62,823 | $34,478 | $17,393 | $847 | $115,542 |
| Dec | $64,986 | $35,156 | $17,971 | $634 | $118,745 |
| **Total 2023** | **$767,388** | **$418,093** | **$208,360** | **$8,294** | **$1,402,135** |

#### Channels in 2024, month by month

| Month | Dine-in | Takeout | Delivery | Service Type | Total |
|---|---|---|---|---|---|
| Jan | $64,844 | $35,905 | $17,151 | $596 | $118,496 |
| Feb | $59,601 | $33,649 | $16,686 | $824 | $110,760 |
| Mar | $65,981 | $35,827 | $17,100 | $414 | $119,321 |
| Apr | $63,858 | $35,226 | $17,302 | $479 | $116,865 |
| May | $65,676 | $35,008 | $17,058 | $1,056 | $118,798 |
| Jun | $63,489 | $33,525 | $17,545 | $865 | $115,424 |
| Jul | $65,597 | $35,816 | $18,205 | $623 | $120,242 |
| Aug | $66,118 | $34,489 | $18,124 | $961 | $119,692 |
| Sep | $63,642 | $34,149 | $18,362 | $740 | $116,893 |
| Oct | $64,711 | $36,486 | $18,080 | $817 | $120,095 |
| Nov | $62,275 | $34,335 | $17,714 | $949 | $115,273 |
| Dec | $66,300 | $35,874 | $16,527 | $811 | $119,511 |
| **Total 2024** | **$772,092** | **$420,290** | **$209,852** | **$9,134** | **$1,411,369** |

#### Channels in 2025, month by month

| Month | Dine-in | Takeout | Delivery | Service Type | Total |
|---|---|---|---|---|---|
| Jan | $62,871 | $35,631 | $17,919 | $680 | $117,100 |
| Feb | $59,342 | $31,629 | $14,828 | $701 | $106,499 |
| Mar | $65,503 | $35,649 | $18,791 | $638 | $120,581 |
| Apr | $62,712 | $33,959 | $17,369 | $566 | $114,607 |
| May | $65,242 | $35,391 | $18,110 | $686 | $119,429 |
| Jun | $62,202 | $34,182 | $16,614 | $582 | $113,581 |
| Jul | $66,677 | $35,318 | $17,435 | $559 | $119,988 |
| Aug | $65,916 | $35,995 | $18,004 | $600 | $120,515 |
| Sep | $64,987 | $33,938 | $16,964 | $764 | $116,653 |
| Oct | $65,433 | $34,716 | $18,266 | $464 | $118,879 |
| Nov | $61,582 | $35,300 | $17,312 | $736 | $114,931 |
| Dec | $67,288 | $36,089 | $17,406 | $571 | $121,353 |
| **Total 2025** | **$769,755** | **$417,797** | **$209,018** | **$7,547** | **$1,404,116** |

### Sales by payment method and year

| Payment | 2023 | 2024 | 2025 | 2025 vs 2024 | Percent of total sales 2025 |
|---|---|---|---|---|---|
| Card | $840,629 | $846,139 | $838,998 | -0.8% | 59.8% |
| Cash | $348,137 | $352,984 | $348,577 | -1.2% | 24.8% |
| Mobile | $207,872 | $206,061 | $211,483 | +2.6% | 15.1% |
| General - Universal | $5,497 | $6,184 | $5,058 | -18.2% | 0.4% |

#### Payments in 2023, month by month

| Month | Card | Cash | Mobile | General - Universal | Total |
|---|---|---|---|---|---|
| Jan | $71,733 | $30,378 | $18,676 | $490 | $121,276 |
| Feb | $65,867 | $25,507 | $16,249 | $518 | $108,140 |
| Mar | $73,022 | $28,896 | $17,824 | $496 | $120,239 |
| Apr | $68,623 | $28,964 | $16,486 | $550 | $114,622 |
| May | $71,369 | $28,501 | $18,554 | $575 | $118,999 |
| Jun | $67,930 | $28,934 | $17,272 | $282 | $114,417 |
| Jul | $70,827 | $28,772 | $16,837 | $377 | $116,814 |
| Aug | $71,732 | $29,784 | $17,445 | $453 | $119,416 |
| Sep | $68,301 | $29,852 | $16,907 | $334 | $115,395 |
| Oct | $69,938 | $30,368 | $17,728 | $496 | $118,530 |
| Nov | $69,736 | $28,483 | $16,858 | $464 | $115,542 |
| Dec | $71,553 | $29,698 | $17,034 | $461 | $118,745 |
| **Total 2023** | **$840,629** | **$348,137** | **$207,872** | **$5,497** | **$1,402,135** |

#### Payments in 2024, month by month

| Month | Card | Cash | Mobile | General - Universal | Total |
|---|---|---|---|---|---|
| Jan | $70,838 | $29,760 | $17,280 | $616 | $118,496 |
| Feb | $66,390 | $28,660 | $15,385 | $326 | $110,760 |
| Mar | $71,272 | $29,822 | $17,724 | $502 | $119,321 |
| Apr | $70,224 | $28,628 | $17,458 | $555 | $116,865 |
| May | $70,667 | $29,475 | $18,108 | $548 | $118,798 |
| Jun | $69,337 | $28,376 | $17,028 | $684 | $115,424 |
| Jul | $72,158 | $29,789 | $17,771 | $524 | $120,242 |
| Aug | $71,804 | $30,074 | $17,201 | $613 | $119,692 |
| Sep | $70,638 | $29,904 | $16,016 | $334 | $116,893 |
| Oct | $72,451 | $29,373 | $17,706 | $565 | $120,095 |
| Nov | $68,703 | $29,833 | $16,254 | $482 | $115,273 |
| Dec | $71,657 | $29,291 | $18,128 | $436 | $119,511 |
| **Total 2024** | **$846,139** | **$352,984** | **$206,061** | **$6,184** | **$1,411,369** |

#### Payments in 2025, month by month

| Month | Card | Cash | Mobile | General - Universal | Total |
|---|---|---|---|---|---|
| Jan | $69,612 | $28,638 | $18,316 | $534 | $117,100 |
| Feb | $64,663 | $26,056 | $15,385 | $395 | $106,499 |
| Mar | $72,672 | $30,287 | $17,231 | $391 | $120,581 |
| Apr | $68,481 | $28,239 | $17,461 | $426 | $114,607 |
| May | $71,801 | $28,531 | $18,545 | $552 | $119,429 |
| Jun | $67,479 | $28,729 | $16,979 | $394 | $113,581 |
| Jul | $70,411 | $31,030 | $17,979 | $569 | $119,988 |
| Aug | $72,204 | $29,964 | $18,000 | $346 | $120,515 |
| Sep | $69,603 | $29,662 | $17,071 | $318 | $116,653 |
| Oct | $71,214 | $28,583 | $18,841 | $241 | $118,879 |
| Nov | $68,304 | $28,302 | $17,970 | $354 | $114,931 |
| Dec | $72,554 | $30,557 | $17,707 | $536 | $121,353 |
| **Total 2025** | **$838,998** | **$348,577** | **$211,483** | **$5,058** | **$1,404,116** |

## Discounts

Discounts given each year and month, so every amount has its date. **Percent of sales** = the discount compared with the sales before the discount. These numbers show when discounts happened; they can't prove a discount brought more sales.

### Discounts by year

| Year | Discounts | Percent of sales | Lines with a discount |
|---|---|---|---|
| 2023 | $8,375.40 | 0.6% | 7,948 |
| 2024 | $8,323.20 | 0.6% | 8,084 |
| 2025 | $8,150.80 | 0.6% | 7,936 |

### 2023

Discounts by channel are in the middle columns.

| Month | Discounts | Percent of sales | Dine-in | Takeout | Delivery | Service Type |
|---|---|---|---|---|---|---|
| Jan | $708.40 | 0.6% | $370.40 | $228.00 | $108.00 | $2.00 |
| Feb | $657.00 | 0.6% | $359.20 | $196.00 | $97.00 | $4.80 |
| Mar | $717.40 | 0.6% | $387.40 | $226.00 | $98.00 | $6.00 |
| Apr | $718.40 | 0.6% | $421.20 | $203.20 | $90.00 | $4.00 |
| May | $753.00 | 0.6% | $406.60 | $243.40 | $99.00 | $4.00 |
| Jun | $686.80 | 0.6% | $378.00 | $190.60 | $112.20 | $6.00 |
| Jul | $696.60 | 0.6% | $404.60 | $195.00 | $91.00 | $6.00 |
| Aug | $687.60 | 0.6% | $387.40 | $180.20 | $118.00 | $2.00 |
| Sep | $691.00 | 0.6% | $348.40 | $233.60 | $104.00 | $5.00 |
| Oct | $693.40 | 0.6% | $382.20 | $202.00 | $106.20 | $3.00 |
| Nov | $680.20 | 0.6% | $347.20 | $221.00 | $110.00 | $2.00 |
| Dec | $685.60 | 0.6% | $345.00 | $235.60 | $98.00 | $7.00 |

### 2024

Discounts by channel are in the middle columns.

| Month | Discounts | Percent of sales | Dine-in | Takeout | Delivery | Service Type |
|---|---|---|---|---|---|---|
| Jan | $700.60 | 0.6% | $401.60 | $207.00 | $92.00 | $0.00 |
| Feb | $693.60 | 0.6% | $391.40 | $189.20 | $107.00 | $6.00 |
| Mar | $714.20 | 0.6% | $412.20 | $207.00 | $92.00 | $3.00 |
| Apr | $689.60 | 0.6% | $368.80 | $219.80 | $97.00 | $4.00 |
| May | $709.20 | 0.6% | $372.60 | $224.60 | $109.00 | $3.00 |
| Jun | $643.80 | 0.6% | $375.80 | $170.00 | $94.00 | $4.00 |
| Jul | $801.00 | 0.7% | $464.20 | $231.40 | $102.40 | $3.00 |
| Aug | $680.00 | 0.6% | $376.00 | $208.00 | $91.00 | $5.00 |
| Sep | $680.80 | 0.6% | $352.40 | $219.40 | $106.00 | $3.00 |
| Oct | $703.60 | 0.6% | $376.20 | $215.40 | $111.00 | $1.00 |
| Nov | $658.80 | 0.6% | $372.80 | $174.00 | $109.00 | $3.00 |
| Dec | $648.00 | 0.5% | $348.00 | $212.00 | $84.00 | $4.00 |

### 2025

Discounts by channel are in the middle columns.

| Month | Discounts | Percent of sales | Dine-in | Takeout | Delivery | Service Type |
|---|---|---|---|---|---|---|
| Jan | $719.60 | 0.6% | $359.60 | $222.60 | $133.40 | $4.00 |
| Feb | $634.60 | 0.6% | $356.60 | $193.00 | $81.00 | $4.00 |
| Mar | $666.20 | 0.5% | $356.20 | $195.00 | $110.00 | $5.00 |
| Apr | $679.60 | 0.6% | $346.80 | $209.00 | $120.80 | $3.00 |
| May | $659.20 | 0.5% | $359.60 | $195.60 | $101.00 | $3.00 |
| Jun | $643.60 | 0.6% | $340.00 | $208.60 | $89.00 | $6.00 |
| Jul | $695.60 | 0.6% | $394.80 | $203.80 | $95.00 | $2.00 |
| Aug | $720.20 | 0.6% | $392.00 | $220.20 | $105.00 | $3.00 |
| Sep | $657.80 | 0.6% | $375.00 | $192.80 | $89.00 | $1.00 |
| Oct | $724.40 | 0.6% | $387.20 | $224.20 | $113.00 | $0.00 |
| Nov | $658.20 | 0.6% | $375.20 | $187.00 | $90.00 | $6.00 |
| Dec | $691.80 | 0.6% | $395.00 | $185.60 | $101.00 | $10.20 |

### The 10 days with the most discounts

Every day is in the file *daily_detail.csv* that comes with this report (it opens in Excel).

| Date | Day | Discounts | Lines with a discount | Sales that day |
|---|---|---|---|---|
| Feb 28, 2023 | Tuesday | $60.60 | 20 | $4,461 |
| Jan 23, 2025 | Thursday | $57.80 | 30 | $4,281 |
| Dec 20, 2023 | Wednesday | $51.40 | 14 | $3,300 |
| Sep 26, 2023 | Tuesday | $50.40 | 25 | $3,732 |
| Jul 11, 2024 | Thursday | $49.80 | 22 | $3,220 |
| Feb 17, 2024 | Saturday | $47.60 | 33 | $4,058 |
| Feb 01, 2023 | Wednesday | $46.20 | 28 | $3,923 |
| Oct 28, 2025 | Tuesday | $43.80 | 25 | $4,166 |
| Nov 27, 2023 | Monday | $43.20 | 31 | $3,504 |
| Apr 19, 2023 | Wednesday | $43.00 | 28 | $3,962 |

### Rule: every discount must still cover the cost

A discount should never be higher than what the item leaves after its cost. The price after the discount always has to cover the cost; otherwise every sale with that discount loses money.

*To check this rule item by item we need the file: Menu with the cost of each item (item, unit_cost).*

## Employees

Sales recorded under each employee, **for each year and month** (not the whole time frame mixed). Compare with care: people work different hours, shifts and roles. With the hours-worked file we can also show sales per hour worked.

### Sales by employee and year

| Employee | 2023 | 2024 | 2025 | 2025 vs 2024 | Percent of total sales 2025 |
|---|---|---|---|---|---|
| Luis Gómez | $230,086 | $235,220 | $232,629 | -1.1% | 16.6% |
| Diego Ramírez | $230,744 | $231,150 | $232,135 | +0.4% | 16.5% |
| Sofía Núñez | $231,156 | $233,302 | $231,266 | -0.9% | 16.5% |
| María José | $232,202 | $229,507 | $230,997 | +0.6% | 16.5% |
| Ana López | $229,903 | $231,541 | $229,938 | -0.7% | 16.4% |
| Carlos Peña | $230,998 | $233,947 | $229,784 | -1.8% | 16.4% |
| Supervisor | $17,047 | $16,702 | $17,367 | +4.0% | 1.2% |

### 2023

Totals for 2023 only (January to December 2023 inside the time frame).

| Employee | Sales | Orders | Average sale per order | Discounts as % of sales |
|---|---|---|---|---|
| María José | $232,202 | 13,881 | $16.73 | 0.6% |
| Sofía Núñez | $231,156 | 13,605 | $16.99 | 0.6% |
| Carlos Peña | $230,998 | 13,752 | $16.80 | 0.6% |
| Diego Ramírez | $230,744 | 13,637 | $16.92 | 0.6% |
| Luis Gómez | $230,086 | 13,663 | $16.84 | 0.6% |
| Ana López | $229,903 | 13,634 | $16.86 | 0.6% |
| Supervisor | $17,047 | 1,191 | $14.31 | 0.5% |

#### Sales by employee in 2023, month by month

| Month | María José | Sofía Núñez | Carlos Peña | Diego Ramírez | Luis Gómez | Ana López | Supervisor | Total |
|---|---|---|---|---|---|---|---|---|
| Jan | $20,367 | $20,236 | $20,291 | $19,200 | $19,920 | $19,774 | $1,488 | $121,276 |
| Feb | $16,544 | $18,373 | $17,641 | $17,614 | $18,169 | $18,320 | $1,480 | $108,140 |
| Mar | $20,853 | $19,440 | $19,511 | $19,892 | $19,704 | $19,202 | $1,637 | $120,239 |
| Apr | $19,253 | $19,372 | $17,846 | $19,265 | $19,095 | $18,626 | $1,165 | $114,622 |
| May | $21,499 | $20,174 | $18,902 | $19,772 | $18,798 | $18,596 | $1,258 | $118,999 |
| Jun | $18,798 | $18,483 | $18,748 | $19,057 | $18,960 | $18,874 | $1,497 | $114,417 |
| Jul | $19,026 | $18,778 | $18,841 | $19,528 | $20,437 | $18,783 | $1,420 | $116,814 |
| Aug | $19,285 | $19,953 | $20,483 | $19,634 | $18,556 | $20,236 | $1,268 | $119,416 |
| Sep | $19,369 | $18,340 | $19,269 | $19,790 | $18,916 | $18,398 | $1,313 | $115,395 |
| Oct | $19,380 | $20,518 | $20,298 | $18,618 | $18,571 | $19,653 | $1,493 | $118,530 |
| Nov | $19,279 | $18,681 | $19,260 | $18,814 | $18,837 | $19,375 | $1,294 | $115,542 |
| Dec | $18,550 | $18,808 | $19,907 | $19,560 | $20,122 | $20,066 | $1,734 | $118,745 |
| **Total 2023** | **$232,202** | **$231,156** | **$230,998** | **$230,744** | **$230,086** | **$229,903** | **$17,047** | **$1,402,135** |

### 2024

Totals for 2024 only (January to December 2024 inside the time frame).

| Employee | Sales | Orders | Average sale per order | Discounts as % of sales |
|---|---|---|---|---|
| Luis Gómez | $235,220 | 13,885 | $16.94 | 0.6% |
| Carlos Peña | $233,947 | 13,892 | $16.84 | 0.6% |
| Sofía Núñez | $233,302 | 13,750 | $16.97 | 0.6% |
| Ana López | $231,541 | 13,795 | $16.78 | 0.5% |
| Diego Ramírez | $231,150 | 13,863 | $16.67 | 0.6% |
| María José | $229,507 | 13,662 | $16.80 | 0.6% |
| Supervisor | $16,702 | 1,160 | $14.40 | 0.6% |

#### Sales by employee in 2024, month by month

| Month | Luis Gómez | Carlos Peña | Sofía Núñez | Ana López | Diego Ramírez | María José | Supervisor | Total |
|---|---|---|---|---|---|---|---|---|
| Jan | $19,385 | $19,554 | $18,868 | $20,056 | $19,488 | $19,652 | $1,492 | $118,496 |
| Feb | $18,433 | $17,903 | $18,940 | $18,121 | $17,195 | $18,538 | $1,630 | $110,760 |
| Mar | $20,385 | $18,788 | $20,587 | $20,496 | $20,660 | $17,353 | $1,052 | $119,321 |
| Apr | $19,958 | $19,056 | $19,097 | $18,642 | $19,350 | $19,441 | $1,320 | $116,865 |
| May | $19,044 | $19,619 | $19,929 | $19,700 | $20,185 | $18,837 | $1,484 | $118,798 |
| Jun | $19,401 | $19,094 | $19,656 | $18,519 | $18,327 | $18,894 | $1,532 | $115,424 |
| Jul | $19,914 | $20,808 | $19,442 | $19,385 | $19,557 | $19,810 | $1,326 | $120,242 |
| Aug | $20,343 | $20,808 | $19,425 | $19,666 | $18,908 | $18,900 | $1,642 | $119,692 |
| Sep | $19,818 | $18,977 | $19,090 | $19,250 | $19,450 | $18,992 | $1,316 | $116,893 |
| Oct | $19,718 | $20,478 | $19,895 | $19,201 | $19,913 | $19,607 | $1,284 | $120,095 |
| Nov | $18,780 | $19,447 | $18,635 | $19,020 | $18,714 | $19,522 | $1,155 | $115,273 |
| Dec | $20,041 | $19,416 | $19,738 | $19,484 | $19,402 | $19,961 | $1,470 | $119,511 |
| **Total 2024** | **$235,220** | **$233,947** | **$233,302** | **$231,541** | **$231,150** | **$229,507** | **$16,702** | **$1,411,369** |

### 2025

Totals for 2025 only (January to December 2025 inside the time frame).

| Employee | Sales | Orders | Average sale per order | Discounts as % of sales |
|---|---|---|---|---|
| Luis Gómez | $232,629 | 13,654 | $17.04 | 0.6% |
| Diego Ramírez | $232,135 | 13,780 | $16.85 | 0.6% |
| Sofía Núñez | $231,266 | 13,502 | $17.13 | 0.6% |
| María José | $230,997 | 13,569 | $17.02 | 0.6% |
| Ana López | $229,938 | 13,568 | $16.95 | 0.6% |
| Carlos Peña | $229,784 | 13,523 | $16.99 | 0.5% |
| Supervisor | $17,367 | 1,196 | $14.52 | 0.6% |

#### Sales by employee in 2025, month by month

| Month | Luis Gómez | Diego Ramírez | Sofía Núñez | María José | Ana López | Carlos Peña | Supervisor | Total |
|---|---|---|---|---|---|---|---|---|
| Jan | $19,589 | $18,944 | $19,008 | $19,711 | $19,784 | $18,528 | $1,536 | $117,100 |
| Feb | $18,036 | $17,226 | $17,734 | $17,378 | $16,827 | $17,962 | $1,335 | $106,499 |
| Mar | $20,103 | $20,237 | $19,828 | $20,289 | $19,115 | $19,548 | $1,461 | $120,581 |
| Apr | $18,332 | $19,286 | $18,578 | $19,247 | $18,696 | $18,952 | $1,517 | $114,607 |
| May | $19,041 | $20,652 | $19,773 | $19,033 | $19,795 | $19,406 | $1,729 | $119,429 |
| Jun | $18,494 | $18,698 | $19,110 | $18,826 | $18,351 | $18,568 | $1,534 | $113,581 |
| Jul | $20,215 | $19,554 | $20,077 | $19,480 | $20,315 | $18,891 | $1,457 | $119,988 |
| Aug | $20,463 | $19,189 | $19,939 | $19,540 | $19,197 | $20,673 | $1,514 | $120,515 |
| Sep | $20,268 | $19,207 | $18,819 | $18,524 | $19,140 | $19,264 | $1,432 | $116,653 |
| Oct | $19,310 | $20,957 | $19,472 | $19,672 | $18,803 | $19,176 | $1,490 | $118,879 |
| Nov | $18,495 | $18,673 | $19,002 | $19,740 | $18,804 | $19,173 | $1,043 | $114,931 |
| Dec | $20,284 | $19,513 | $19,925 | $19,558 | $21,111 | $19,644 | $1,319 | $121,353 |
| **Total 2025** | **$232,629** | **$232,135** | **$231,266** | **$230,997** | **$229,938** | **$229,784** | **$17,367** | **$1,404,116** |

## Profit: what is left after costs

Sales are not profit. To show what is left after costs we need these files from the business (CSV or Excel, any of them helps):

- Menu with the cost of each item (item, unit_cost)
- Staff and hourly pay (employee, hourly_rate)
- Hours worked (date, employee, hours)
- Monthly bills: rent, utilities... (month, expense_type, amount)
- Stock bought and thrown away (month, purchases, waste)
- Card processing fees (payment_method, percent)

## How to read these numbers

- Time frame: Jan 01, 2023 - Dec 31, 2025 (3 years: 2023, 2024, 2025). Only clean rows are counted; rows still waiting for a fix are left out (see *Rows still pending* in this report).
- **Sales** = the amount of each sale line minus its discount. Taxes, tips and refunds are not in the file.
- **Average per day** = sales divided by the calendar days of that month inside the time frame.
- **+ / -** = the change compared with the period before, in percent: + went up, - went down.
- Sales are not cash in the bank: compare them with card settlements and deposits.
- Charts are in the PDF report. The daily detail is in the file *daily_detail.csv* (opens in Excel).

---
El Austral Consultant · elaustralconsultant@gmail.com