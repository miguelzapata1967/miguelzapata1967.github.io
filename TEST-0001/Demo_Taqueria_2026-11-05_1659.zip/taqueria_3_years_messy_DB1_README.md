# Clean-up Report - Demo Taqueria

| | |
|---|---|
| Customer ID | TEST-0001 |
| Report ID | TEST-0001-basic-20261105165957-db1 |
| Business type | Restaurant |
| Analysis time frame | Jan 01, 2023 - Dec 31, 2025 |
| Data period (order_datetime) | Jan 01, 2023 - Dec 31, 2025 |
| Source file | taqueria_3_years_messy.csv |
| Created | 2026-11-05 17:14 |

**Status:** 46 rows still need a fix. They are left out of the numbers below and saved in the bad rows file so they can be fixed and sent again.

## Data quality
- Rows uploaded: 300,060
- Clean rows: 299,976
- Bad rows found: 26,210
- Fixed by you and added back: 26,126
- Deleted by you (duplicates or unusable): 38
- Still to fix: 46

## Problems found at upload

| Problem | Rows |
|---|---|
| missing information | 6,564 |
| garbled characters | 5,431 |
| text in a number column | 3 |
| not a valid date | 3 |
| negative number | 15 |
| spelling differs | 14,744 |
| unusual value | 4 |
| duplicate row | 60 |

## Column by column

Only columns that need attention. *Missing data, not bad* and *partly reported, not bad* columns don't make any row bad.

| Column | Status | Blank | Wrong cells |
|---|---|---|---|
| order_datetime | needs checking | 0 | 3 |
| item | needs checking | 0 | 1,616 |
| category | needs checking | 0 | 8,940 |
| quantity | needs checking | 0 | 8 |
| unit_price | needs checking | 0 | 4 |
| order_total | needs checking | 0 | 9 |
| channel | needs checking | 1,802 | 5,888 |
| employee | needs checking | 3,601 | 7,551 |
| payment_method | needs checking | 1,200 | 2,992 |

## What we did in this job
1. Received **taqueria_3_years_messy.csv** with 300,060 rows and saved an untouched copy with its fingerprint.
2. Identified the columns. All column names were kept as they are.
3. Checked every column first, then every cell: blanks, text in number columns, dates, negative and unusual numbers, spellings, garbled accents and duplicates.
4. Found 26,210 bad rows. You fixed 26,126, deleted 38 and 46 are still to fix.
5. Every fixed row is marked **fixed** with the date, and every row has its own fingerprint.

## Analysis
**Plan: Basic.** $1,200.00 per database. Includes data clean-up, data repair and the clerk hours saved. No data analysis.  
*Need the numbers too? Add the Analysis for $400.00 per database.*

---
El Austral Consultant · elaustralconsultant@gmail.com